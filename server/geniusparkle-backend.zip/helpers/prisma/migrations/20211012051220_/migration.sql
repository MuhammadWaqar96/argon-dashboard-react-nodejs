-- AlterTable
ALTER TABLE "account" ALTER COLUMN "birthday" DROP NOT NULL;
