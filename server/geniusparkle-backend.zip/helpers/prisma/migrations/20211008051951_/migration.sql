-- AlterTable
ALTER TABLE "account" ADD COLUMN     "discordTokens" JSON;
